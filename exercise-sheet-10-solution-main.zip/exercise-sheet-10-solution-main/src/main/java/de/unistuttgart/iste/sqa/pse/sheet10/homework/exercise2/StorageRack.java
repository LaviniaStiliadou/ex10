package de.unistuttgart.iste.sqa.pse.sheet10.homework.exercise2;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import de.unistuttgart.iste.sqa.pse.sheet10.homework.exercise2.Items.StationeryItem;

/**
 * Represents a warehouse that can hold a fixed number of items.
 * The number of holdable items is defined by the capacity of the storage rack.
 */
public final class StorageRack {
	// @ private instance invariant capacity > 0;
	// @ private instance invariant numberOfItems >= 0;
	// @ private instance invariant numberOfItems <= capacity;
	// @ private instance invariant for every item in storedItems there must be a mapping in mappingToCompartmentNumber;

	private final int capacity;
	private int numberOfItems;
	// TODO: Add data structures for exercises 1a and 1c here.
	private final ArrayList<Optional<StationeryItem>> storedItems;
	private final Map<Identifier, Integer> mappingToCompartmentNumber;

	/*@
	@ requires capacity > 0;
	@ ensures this.capacity == capacity;
	@ ensures storedItems.size() == capacity;
	@ ensures mappingToCompartmentNumber != null;
	@*/
	/**
	 * Creates a new storage rack with the given capacity.
	 *
	 * @param capacity capacity of the storage rack.
	 *
	 * @throws IllegalArgumentException If capacity is less than 1.
	 */
	public StorageRack(final int capacity) {
		if (capacity <= 0) {
			throw new IllegalArgumentException("A warehouse must have a minimum capacity of 1.");
		}
		this.capacity = capacity;
		numberOfItems = 0;
		// TODO initialize data structures for exercises 1a and 1c here.
		storedItems = new ArrayList<>(capacity);
		/*@
		@ loop_invariant i array compartments have been initialized;
		@ decreasing capacity - i;
		@*/
		for (int i = 0; i < capacity; i++) {
			storedItems.add(Optional.empty());
		}
		mappingToCompartmentNumber = new HashMap<>();
	}

	/*@
	@ requires item != null;
	@ requires numberOfItems < capacity;
	@ ensures storedItems.contains(item);
	@ ensures numberOfItems == \old(numberOfItems) + 1;
	@ ensures mappingToCompartmentNumber contains the mapping from the item's identifier to its compartment number;
	@*/
	/**
	 * Adds an item to the storage rack.
	 *
	 * @param stationeryItem The item to be added.
	 * @throws IllegalArgumentException If the given item is null.
	 * @throws IllegalStateException If the storage rack is already full.
	 */
	public void addItem(final StationeryItem stationeryItem) {
		// TODO implement exercises 1b and 1d here.
		if (stationeryItem == null) {
			throw new IllegalArgumentException("Null items cannot be added to a storage rack.");
		}
		if (numberOfItems >= capacity) {
			throw new IllegalStateException("The storage rack is already full.");
		}
		if (storedItems.contains(Optional.of(stationeryItem))) {
			throw new IllegalArgumentException("Item is already stored at the warehouse.");
		}
		addItemToEmptyCompartment(stationeryItem);
		numberOfItems++;
	}
	/*@
	@ requires item != null
	@ ensures storedItems contains the given item;
	@ ensures mappingToCompartmentNumber contains the mapping from the given item's identifier to its compartment number;
	@*/
	/**
	 * Adds the item to the first empty compartment.
	 *
	 * @param stationeryItem The item to be added
	 */
	private void addItemToEmptyCompartment(final StationeryItem stationeryItem) {
		assert stationeryItem != null;
		/*@
		@ loop_invariant i array compartments have been checked for an empty space;
		@ decreasing capacity - i;
		@*/
		for (int i = 0; i < capacity; i++) {
			if (storedItems.get(i).isEmpty()) {
				storedItems.set(i, Optional.of(stationeryItem));
				mappingToCompartmentNumber.put(stationeryItem.getIdentifier(), i);
				break;
			}
		}
	}

	private void addItemToEmptyCompartmentWithoutBreak(final StationeryItem stationeryItem) {
		assert stationeryItem != null;
		int i = 0;
		/*@
		@ loop_invariant checked as many compartments as loop iterations already executed
		@ decreasing remaining compartments to be checked;
		@*/
		while (this.storedItems.get(i).isPresent()) {
			++i;
		}
		var id = stationeryItem.getIdentifier();

		this.mappingToCompartmentNumber.put(id, i);
		this.storedItems.set(i, Optional.of(stationeryItem));
	}

	/*@
	@ requires 0 <= compartmentNumber < capacity;
	@ ensures the compartment with the given number is empty;
	@ ensures mappingToCompartmentNumber does not contain a mapping for the removed item's identifier
	@ ensures numberOfItems == \old(numberOfItems) - 1;
	@*/
	/**
	 * Removes an item from the compartment with the number.
	 *
	 * @param compartmentNumber The compartment number to empty.
	 * @throws IllegalArgumentException If the given compartment number does not exist in this storage rack.
	 */
	public void removeItem(final int compartmentNumber) {
		// TODO implement exercises 1b and 1d here.
		if (compartmentNumber < 0 || compartmentNumber >= capacity) {
			throw new IllegalArgumentException("The given compartment number is invalid.");
		}
		if (storedItems.get(compartmentNumber).isPresent()) {
			mappingToCompartmentNumber.remove(storedItems.get(compartmentNumber).get().getIdentifier());
			storedItems.set(compartmentNumber, Optional.empty());
			this.numberOfItems--;
		}
	}

	/*@
	@ requires 0 <= compartmentNumber < capacity;
	@*/
	/**
	 * Retrieves the item in the given compartment number in this storage rack.
	 *
	 * @param compartmentNumber The compartment number from where the item should be retrieved.
	 * @return The requested item, or an empty optional if the given compartment is empty.
	 * @throws IllegalArgumentException If the given compartment number does not exist in this warehouse.
	 */
	public /*@ pure @*/ Optional<StationeryItem> getItem(final int compartmentNumber) {
		// TODO implement exercise 1b here.
		if (compartmentNumber < 0 || compartmentNumber >= capacity) {
			throw new IllegalArgumentException("The given compartment number is invalid.");
		}
        return storedItems.get(compartmentNumber);
	}

	/*@
	@ requires identification != null;
	@ ensures index.containsKey(identification) <==> \result.isPresent();
	@ ensures index.containsKey(identification) ==> \result.get() == index.get(identification);
	@*/
	/**
	 * Returns the compartment number that the given item identifier is stored in.
	 *
	 * @param identifier The identifier of the item whose compartment number to look for.
	 * @return The compartment number corresponding to the identifier, or an empty optional if there is no item with the
	 * 			given identifier in the storage rack..
	 * @throws IllegalArgumentException If the given identifier is null.
	 */
	public /*@ pure @*/ Optional<Integer> getCompartmentNumberOf(final Identifier identifier) {
		// TODO implement exercise 1d here.
		if (identifier == null) {
			throw new IllegalArgumentException("The item identifier cannot be null.");
		}
		if (mappingToCompartmentNumber.containsKey(identifier)) {
			return Optional.of(mappingToCompartmentNumber.get(identifier));
		} else {
			return Optional.empty();
		}
	}

	/*@
	@ ensures \result == capacity;
	@*/
	/**
	 * @return The capacity of this warehouse in items.
	 */
	public /*@ pure @*/ int getCapacity() {
		return capacity;
	}

	/*@
	@ ensures \result == numberOfItems;
	@*/
	/**
	 * @return The number of items in this warehouse.
	 */
	public /*@ pure @*/ int getNumberOfItems() {
		return this.numberOfItems;
	}
}
