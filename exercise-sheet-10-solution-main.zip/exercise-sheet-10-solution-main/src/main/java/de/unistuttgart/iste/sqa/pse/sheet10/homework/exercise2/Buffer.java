package de.unistuttgart.iste.sqa.pse.sheet10.homework.exercise2;

import java.util.LinkedList;
import java.util.Queue;

import de.unistuttgart.iste.sqa.pse.sheet10.homework.exercise2.Items.StationeryItem;

/**
 * Represents a buffer for temporary storage of items.
 */
public final class Buffer {

	//TODO: Add data structure for exercise 1f here.
	private final Queue<StationeryItem> queue;

	/**
	 * Creates a new buffer object.
	 */
	public Buffer() {
		// TODO: Initialize data structure for exercise 1f here.
		queue = new LinkedList<>();
	}

	/*@
	@ requires item != null;
	@ ensures !isEmpty();
	@*/
	/**
	 * Adds a given item to the buffer.
	 * @param stationeryItem The item to be added.
	 * @throws IllegalArgumentException If the given item is null.
	 */
	public void bufferItem(final StationeryItem stationeryItem) {
		// TODO implement exercise 1g here.
		if (stationeryItem == null) {
			throw new IllegalArgumentException("A null item cannot be buffered.");
		}
		queue.add(stationeryItem); // oder offer()
	}

	/*@
	@ requires !isEmpty();
	@ ensures the lowest item is removed from the buffer and returned;
	@*/
	/**
	 * Releases the lowest item in the buffer and returns it.
	 * @return The released item.
	 * @throws IllegalStateException If the buffer is empty.
	 */
	public StationeryItem releaseItem() {
		// TODO implement exercise 1g here.
		if (isEmpty()) {
			throw new IllegalStateException("The buffer is empty.");
		}
		return this.queue.remove(); // oder poll()
	}

	/*@
	@ ensures \result == queue.isEmpty();
	@*/
	/**
	 * Checks whether this buffer is empty.
	 * @return Whether this buffer is empty.
	 */
	public /*@ pure @*/ boolean isEmpty() {
		// TODO implement exercise 1g here.
		return queue.isEmpty(); // TODO delete this line if necessary.
	}
}
