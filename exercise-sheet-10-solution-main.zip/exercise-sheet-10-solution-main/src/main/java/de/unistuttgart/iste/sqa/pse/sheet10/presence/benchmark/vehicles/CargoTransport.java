package de.unistuttgart.iste.sqa.pse.sheet10.presence.benchmark.vehicles;

/**
 * Cargo transportation.
 */
public abstract class CargoTransport implements Vehicle {
	//@invariant baseWeight > 0;
	final private double baseWeight;
	//@invariant cargoWeight > 0;
	final private double cargoWeight;
	//@invariant engine != null;
	final private Engine engine;
	
	final private String vehicleCode;
	
	/*@
	 @requires baseWeight > 0;
	 @requires cargoWeight > 0;
	 @requires engine != null;
	*/
	/**
	 * Create a new cargo transportation vehicle.
	 * 
	 * Requires baseWeight and cargoWeight are greater than 0.
	 * 
	 * @param baseWeight Vehicle base weight
	 * @param cargoWeight Maximum cargo weight
	 * @param engine Vehicle Engine
	 */
	public CargoTransport(final double baseWeight, final double cargoWeight, final Engine engine, final String vehicleCode) {
		if (baseWeight <= 0 || cargoWeight <= 0) {
			throw new IllegalArgumentException("Weights must be positive");
		} else if (engine == null) {
			throw new IllegalArgumentException("Engine must exist");
		} 
		if (vehicleCode == null || vehicleCode.isEmpty()) {
			throw new IllegalArgumentException("Code must exist");
		}
		this.baseWeight = baseWeight;
		this.cargoWeight = cargoWeight;
		this.engine = engine;
		this.vehicleCode = vehicleCode;
	}
	
	/**
	 * Get the vehicle base weight.
	 * 
	 * @return Base weight
	 */
	public double getBaseWeight() {
		return baseWeight;
	}
	
	/**
	 * Get the maximum cargo weight.
	 *
	 * @return Maximum cargo weight
	 */
	public double getCargoWeight() {
		return cargoWeight;
	}
	
	@Override
	public double getWeight() {
		return baseWeight + cargoWeight;
	}
	
	@Override
	public Engine getEngine() {
		return engine;
	}
	
	@Override
	public double getPerformance() {
		final double power = engine.getPower();
		return power / getWeight();
	}
	
	@Override
	public String getVehicleCode() {
		return this.vehicleCode;
		
	}
}
