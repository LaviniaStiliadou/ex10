package de.unistuttgart.iste.sqa.pse.sheet10.presence.benchmark.vehicles;

/**
 *
 */
public abstract class PersonalTransport implements Vehicle {
	//@invariant weight > 0;
	final private double weight;
	//@invariant engine != null;
	final private Engine engine;
	
	final private String vehicleCode;
	
	/*@
	 @requires weight > 0;
	 @requires engine != null;
	*/
	/**
	 * Create a new personal vehicle.
	 * 
	 * The weight needs to be positive.
	 * 
	 * @param weight Weight of the vehicle
	 * @param engine Vehicle engine
	 */
	public PersonalTransport(final double weight, final Engine engine, final String vehicleCode) {
		if (weight <= 0) {
			throw new IllegalArgumentException("Weight must be positive");
		} else if (engine == null) {
			throw new IllegalArgumentException("Engine must exist");
		}
		// TODO IAE for code.
		this.weight = weight;
		this.engine = engine;
		this.vehicleCode = vehicleCode;
	}
	
	@Override
	public double getWeight() {
		return weight;
	}
	
	@Override
	public Engine getEngine() {
		return engine;
	}
	
	@Override
	public double getPerformance() {
		final double power = engine.getPower();
		return power / weight;
	}
	
	@Override
	public String getVehicleCode() {
		return this.vehicleCode;
		
	}
}
