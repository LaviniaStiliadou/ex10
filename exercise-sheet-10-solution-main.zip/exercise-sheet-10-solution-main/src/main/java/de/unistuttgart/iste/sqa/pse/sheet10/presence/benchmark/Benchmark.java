package de.unistuttgart.iste.sqa.pse.sheet10.presence.benchmark;

import de.unistuttgart.iste.sqa.pse.sheet10.presence.benchmark.vehicles.Car;
import de.unistuttgart.iste.sqa.pse.sheet10.presence.benchmark.vehicles.CheatingCar;
import de.unistuttgart.iste.sqa.pse.sheet10.presence.benchmark.vehicles.ContainerShip;
import de.unistuttgart.iste.sqa.pse.sheet10.presence.benchmark.vehicles.Engine;
import de.unistuttgart.iste.sqa.pse.sheet10.presence.benchmark.vehicles.HGV;
import de.unistuttgart.iste.sqa.pse.sheet10.presence.benchmark.vehicles.Yacht;
import java.util.Set;

/**
 *
 */
public class Benchmark {
	public static void main(String... args) {
		var astronMartin = new Car(3.5, new Engine(42000, "007"), "S-OS-6424");
		var tinyCar = new Car(1.5, new Engine(42000, "007"), "S-OS-6423");
		var truck = new HGV(6000, 25000, new Engine(2300, "B"), "S-TT-2012");
		var everGiven = new ContainerShip(65867000, 200000000, new Engine(59300, "M"), "DF-12354");
		var yacht = new Yacht(16000, new Engine(4000, "engineId"), "YA-245754");
		var cheater = new CheatingCar(1600, new Engine(242, "770"),"S-OX-1001");
		
		var shortTrack = new TestRoute(2, 80, "sprint");
		var longTrack = new TestRoute(200, 80, "travel");
		
		var test = new TestBench(Set.of(astronMartin, tinyCar, truck, everGiven, yacht, cheater), Set.of(shortTrack, longTrack));
		
		test.runAllTests();
	}
}
