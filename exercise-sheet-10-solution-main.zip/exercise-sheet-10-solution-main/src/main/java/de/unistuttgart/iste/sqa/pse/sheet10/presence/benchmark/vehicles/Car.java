package de.unistuttgart.iste.sqa.pse.sheet10.presence.benchmark.vehicles;

/**
 *
 */
public /* final */ class Car extends PersonalTransport {
	
	/*@
	 @requires weight > 0;
	 @requires engine != null;
	*/
	public Car(final double weight, final Engine engine, final String code) {
		super(weight, engine, code);
	}

}
