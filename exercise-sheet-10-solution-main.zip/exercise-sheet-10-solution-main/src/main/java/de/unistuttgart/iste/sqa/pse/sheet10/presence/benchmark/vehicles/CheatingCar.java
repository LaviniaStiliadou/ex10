package de.unistuttgart.iste.sqa.pse.sheet10.presence.benchmark.vehicles;

/**
 *
 */
public class CheatingCar extends Car {

	/*@
	 @requires weight > 0;
	 @requires engine != null;
	*/
	public CheatingCar(double weight, Engine engine, String code) {
		super(weight, engine, code);
	}

	@Override
	public double getPerformance() {
		return super.getPerformance() * 1.25;
	}
}
