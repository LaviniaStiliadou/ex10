package de.unistuttgart.iste.sqa.pse.sheet10.presence.benchmark;

import de.unistuttgart.iste.sqa.pse.sheet10.presence.benchmark.vehicles.Vehicle;
import java.util.Set;

/**
 *
 */
public class TestBench {
	//@invariant vehicles != null;
	final private Set<Vehicle> vehicles;
	//@invariant routes != null;
	final private Set<TestRoute> routes;
	
	/*@
	 @requires vehicles != null;
	 @requires routes != null;
	*/
	/**
	 * Create a new TestBench.
	 *
	 * @param vehicles Vehicles to test
	 * @param routes Routes to test on
	 */
	public TestBench(final Set<Vehicle> vehicles, final Set<TestRoute> routes) {
		if (vehicles == null || routes == null) {
			throw new IllegalArgumentException();
		}
		this.vehicles = vehicles;
		this.routes = routes;
	}
	
	/**
	 * Run tests for all vehicles on all routes.
	 */
	public void runAllTests() {
		//@loop_invariant run as many tests, as loop iterations got executed times vehicles.size();
		//@decreasing #of routes not yet tested
		for (var route : routes) {
			//@loop_invariant run as many tests, as loop iterations got executed
			//@decreasing #of vehicles not yet tested
			for (var vehicle : vehicles) {
				var test = new TestRun(route, vehicle);
				test.executeTest();
				
				if (test.testSucceded()) {
					System.out.format("Test %s on %s succeeded\n", vehicle.getVehicleCode(), route.name()); 
				} else {
					System.out.format("Test %s on %s failed\n", vehicle.getVehicleCode(), route.toString());
				}
			}
		}
		// Ausgabe danach oder waehrenddessen?
	}
}
