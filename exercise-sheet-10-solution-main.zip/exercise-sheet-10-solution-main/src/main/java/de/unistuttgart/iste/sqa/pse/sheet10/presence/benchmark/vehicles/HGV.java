package de.unistuttgart.iste.sqa.pse.sheet10.presence.benchmark.vehicles;

/**
 *
 */
public class HGV extends CargoTransport {

	/*@
	 @requires baseWeight > 0;
	 @requires cargoWeight > 0;
	 @requires engine != null;
	*/
	public HGV(double baseWeight, double cargoWeight, Engine engine, final String code) {
		super(baseWeight, cargoWeight, engine, code);
	}

}
