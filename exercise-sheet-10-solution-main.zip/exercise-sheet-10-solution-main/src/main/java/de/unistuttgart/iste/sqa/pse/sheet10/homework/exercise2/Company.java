package de.unistuttgart.iste.sqa.pse.sheet10.homework.exercise2;

import java.util.HashSet;
import java.util.Optional;
import java.util.Random;
import java.util.Set;

import de.unistuttgart.iste.sqa.pse.sheet10.homework.exercise2.Items.Compass;
import de.unistuttgart.iste.sqa.pse.sheet10.homework.exercise2.Items.StationeryItem;
import de.unistuttgart.iste.sqa.pse.sheet10.homework.exercise2.Items.Pen;
import de.unistuttgart.iste.sqa.pse.sheet10.homework.exercise2.Items.Ruler;

/**
 * Represents a company.
 *
 * A company stores items and processes orders.
 */
public final class Company {

	private final StorageRack itemStorageRack;
	private final Buffer orderBuffer;
	// TODO: Add data structure for exercise 1i here.
	private final Set<Customer> pastCustomers;

	/*@
	@ ensures itemStorageRack != null;
	@ ensures that the storage rack has a capacity of 75;
	@ ensures orderBuffer != null && orderBuffer.isEmpty();
	@ ensures pastCustomers != null && pastCustomers.isEmpty();
	@*/
	/**
	 * Creates a new company object.
	 */
	public Company() {
		orderBuffer = new Buffer();
		// TODO: implement exercises 1e and 1i here.
		itemStorageRack = new StorageRack(75);
		pastCustomers = new HashSet<>();
	}

	/*@
	@ requires item != null;
	@ ensures item has been added to the storageRack if there was enough space;
	@*/
	/**
	 * Accepts an item and stores it in the corresponding warehouse if there is enough space.
	 *
	 * @param stationeryItem The item to be handled.
	 * @throws IllegalArgumentException If the item is null.
	 */
	public void storeInStorageRack(final StationeryItem stationeryItem) {
		// TODO: implement exercise 1e here.
		if (stationeryItem == null) {
			throw new IllegalArgumentException("The given item cannot be null.");
		}
		// no more "getWarehouseFor/Of..."
		if (itemStorageRack.getNumberOfItems() < itemStorageRack.getCapacity()) {
			itemStorageRack.addItem(stationeryItem);
		}
	}

	/*@
	@ requires identification != null;
	@ requires customer != null;
	@ ensures the identified item is removed from the storage rack and added to the buffer;
	@ ensures if the customer is a new customer, a present is added to the buffer;
	@ ensures pastCustomers.contains(customer);
	@*/
	/**
	 * Processes an incoming order for a specified item by a given customer.
	 *
	 * @param identifier Identifier to find the ordered item in the storage rack.
	 * @param customer Customer who ordered the item.
	 * @throws IllegalArgumentException If either parameter is null.
	 */
	public void processIncomingOrder(final Identifier identifier, final Customer customer) {
		// TODO implement exercises 1h and 1i here.
		if (identifier == null || customer == null) {
			throw new IllegalArgumentException("The identifier and customer cannot be null.");
		}

		Optional<Integer> compartmentNumber = itemStorageRack.getCompartmentNumberOf(identifier);
		if (compartmentNumber.isPresent()) {
			Optional<StationeryItem> item = itemStorageRack.getItem(compartmentNumber.get());
			if (item.isPresent()) {
				itemStorageRack.removeItem(compartmentNumber.get());
				orderBuffer.bufferItem(item.get());
				handleCustomer(customer);
			}
		}

	}

	/*@
	@ requires customer != null;
	@ ensures if the customer is a new customer, a present is added to the buffer;
	@ ensures pastCustomers.contains(customer);
	@*/
	/**
	 * Checks whether the customer is new to the company.
	 * If the customer is new, a bonus item is provided for him.
	 *
	 * @param customer Customer who ordered the item
	 */
	private void handleCustomer(final Customer customer) {
		assert customer != null;
		if (!pastCustomers.contains(customer)) {
			orderBuffer.bufferItem(getBonusItem());
			pastCustomers.add(customer);
		}
	}

	/*@
	@ ensures \result != null;
	@ ensures \result.getIdentification().getType() == ItemType.PRESENT;
	@*/
	/**
	 * Generates a bonus item for marketing reasons.
	 * 
	 * @return A marketing bonus item.
	 */
	private /*@ pure @*/ StationeryItem getBonusItem() {
		
		switch ((new Random().nextInt(3))) {
		case 1: 
			return new Compass(new Identifier(), "A marketing bonus item.");
		case 2: 
			return new Ruler(new Identifier(), "A marketing bonus item.");
		default:
			return new Pen(new Identifier(), "A marketing bonus item.");
		}
	}

	/**
	 * If items are waiting for packaging, takes the next available item from the buffer and return it.
	 * 
	 * @return Optional next available item for packaging, or an empty Optional if there is none.
	 */
	public Optional<StationeryItem> takeItemForPackaging() {
		if (orderBuffer.isEmpty()) {
			return Optional.empty();
		} else {
			return Optional.of(orderBuffer.releaseItem());
		}
	}
}
