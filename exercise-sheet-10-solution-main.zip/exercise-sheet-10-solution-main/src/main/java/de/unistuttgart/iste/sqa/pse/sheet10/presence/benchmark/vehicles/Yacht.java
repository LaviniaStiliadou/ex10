package de.unistuttgart.iste.sqa.pse.sheet10.presence.benchmark.vehicles;

/**
 *
 */
public class Yacht extends PersonalTransport {

	/*@
	 @requires weight > 0;
	 @requires engine != null;
	*/
	public Yacht(double weight, Engine engine, final String code) {
		super(weight, engine, code);
	}

}
