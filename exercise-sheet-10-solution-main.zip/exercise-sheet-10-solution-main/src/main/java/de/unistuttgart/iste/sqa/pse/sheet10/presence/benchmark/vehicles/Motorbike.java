package de.unistuttgart.iste.sqa.pse.sheet10.presence.benchmark.vehicles;

/**
 *
 */
public class Motorbike extends PersonalTransport {

	/*@
	 @requires weight > 0;
	 @requires engine != null;
	*/
	public Motorbike(double weight, Engine engine , final String code) {
		super(weight, engine, code);
	}

}
