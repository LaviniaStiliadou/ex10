open module exercise {

	requires de.hamstersimulator.objectsfirst.main;
}
